import java.util.Optional;

public class Exercise8 {
    
    static String afficherLaVille(Adresse adresse){
        if(adresse != null){
            String ville = adresse.getVille();
            if (ville != null){}
            return ville.toUpperCase();
        }
    }
    return "VILLE INCONNUE";

    static class Adresse {
        private String ville;
        Adresse(String ville) {
            this.ville = ville;
        }
        String getVille() {
            return ville;
        }
    }
 static Optional<String> afficherVille = Optional.ofNullable(adresse).map(Adresse::getVille).map(String::toUppercase).orElse("VILLE INCONNUE");

    public static void main(String[] args) {

        System.out.println(afficherVille(new Adresse("Paris")));
        System.out.println(afficherVille(new Adresse(null)));
        System.out.println(afficherVille(null));
    }

    private static String afficherVille(Object o) {
    }

}


