import java.util.Optional;

public class CreatingOptionals {
    static String language;

    public CreatingOptionals(String language) {
        this.language = language;
    }

    public static void main(String[] args) {

        Optional<String> contains = Optional.of("Java");
        Optional<String> empty = Optional.empty();

        CreatingOptionals c = new CreatingOptionals("Python");

        Optional<String> empty2 = Optional.ofNullable(language);

        System.out.println(empty2.get());
        System.out.println(empty);
        System.out.println(contains.get());
    }

}
