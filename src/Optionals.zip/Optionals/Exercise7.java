import java.util.Optional;

public class Exercise7 {
    public static void main(String[] args) {
        Optional<Integer> note = Optional.of(14);

        note.filter(keep -> keep >= 10).map(keep -> "Admis avec: " + keep).orElse("Nom admis")
        System.out.println(result);
    }
}
